package com.example.fishtapper

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val REQ_CAPTURE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        root.addView(TextView(this).apply {
            text = "아래 순서대로 진행하세요.\n1) 다른 앱 위에 표시 허용\n2) 접근성에서 FishTapper 켜기\n3) 시작 → 화면 캡처 허용\n4) 게임 실행 후 ON/OFF 버튼으로 켜고 끄기"
            textSize = 15f
        })
        fun btn(label: String, action: () -> Unit) = root.addView(Button(this).apply {
            text = label; setOnClickListener { action() }
        })

        btn("1. 오버레이 권한 설정") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. 접근성 설정 열기") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. 시작") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "오버레이 권한을 먼저 허용하세요", Toast.LENGTH_SHORT).show()
            } else if (TapService.instance == null) {
                Toast.makeText(this, "접근성에서 FishTapper를 먼저 켜세요", Toast.LENGTH_SHORT).show()
            } else {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                @Suppress("DEPRECATION")
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
            }
        }
        setContentView(root)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "시작됨. 게임으로 이동하세요", Toast.LENGTH_SHORT).show()
        }
    }
}
