package com.example.fishtapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class CaptureService : Service() {

    // ===== 조정 가능한 설정값 =====
    private val TAP_X_RATIO = 0.58f      // 터치 x 위치 (0.5 = 정중앙, 클수록 오른쪽)
    private val TAP_Y_RATIO = 0.50f      // 터치 y 위치
    private val LOOP_MS = 70L            // 감지/터치 주기(ms)
    private val MIN_RED_PIXELS = 40      // STOP 버튼 판정 최소 빨간 픽셀 수 (오탐이면 올리기)
    private val MISS_LIMIT = 3           // 연속 N번 안 보이면 터치 중단
    // ==============================

    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var overlay: View? = null
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler

    @Volatile private var enabled = false
    @Volatile private var running = true
    private var cw = 0
    private var ch = 0
    private var dpi = 320
    private var absent = 99

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null || intent == null) return START_NOT_STICKY
        startAsForeground()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        thread = HandlerThread("fishtapper").also { it.start() }
        handler = Handler(thread.looper)
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showOverlay()
        handler.post(loop)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "FishTapper", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cap")
            .setContentTitle("FishTapper 실행 중")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        dpi = dm.densityDpi
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    private fun setupCapture(w: Int, h: Int) {
        reader?.close()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        if (vd == null) {
            vd = projection!!.createVirtualDisplay(
                "fishtapper", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
            )
        } else {
            vd!!.resize(w, h, dpi)
            vd!!.surface = reader!!.surface
        }
        cw = w; ch = h
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try { tick() } catch (_: Exception) {}
            handler.postDelayed(this, LOOP_MS)
        }
    }

    private fun tick() {
        val (w, h) = screenSize()
        if (w != cw || h != ch) setupCapture(w, h)   // 가로/세로 전환 대응

        val img = reader?.acquireLatestImage()
        if (!enabled) { img?.close(); return }

        if (img != null) {
            val found = try { detect(img) } finally { img.close() }
            if (found) absent = 0 else absent++
        }
        if (absent < MISS_LIMIT) {
            TapService.instance?.tap(w * TAP_X_RATIO, h * TAP_Y_RATIO)
        }
    }

    /** 화면 하단 오른쪽 영역에서 빨간 STOP 버튼(뭉쳐있는 빨간 픽셀)을 찾는다. */
    private fun detect(img: Image): Boolean {
        val plane = img.planes[0]
        val buf = plane.buffer
        val rowStride = plane.rowStride
        val pix = plane.pixelStride
        val w = img.width
        val h = img.height
        val step = 3

        var count = 0
        var minX = Int.MAX_VALUE; var maxX = -1
        var minY = Int.MAX_VALUE; var maxY = -1

        var y = (h * 0.55f).toInt()
        while (y < h) {
            var x = (w * 0.5f).toInt()
            while (x < w) {
                val i = y * rowStride + x * pix
                val r = buf.get(i).toInt() and 0xFF
                val g = buf.get(i + 1).toInt() and 0xFF
                val b = buf.get(i + 2).toInt() and 0xFF
                if (r > 190 && g < 90 && b < 100) {
                    count++
                    if (x < minX) minX = x; if (x > maxX) maxX = x
                    if (y < minY) minY = y; if (y > maxY) maxY = y
                }
                x += step
            }
            y += step
        }
        if (count < MIN_RED_PIXELS) return false
        val boxW = (maxX - minX) / step + 1
        val boxH = (maxY - minY) / step + 1
        val fill = count.toFloat() / (boxW * boxH)
        // 한 덩어리로 뭉쳐 있고(채움 비율) 너무 넓게 퍼져 있지 않을 때만 인정
        return fill > 0.3f && (maxX - minX) < w * 0.25f
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        val toggle = TextView(this).apply {
            text = "▶ OFF"; setTextColor(Color.WHITE); textSize = 16f
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        val close = TextView(this).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 16f
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xAA000000.toInt())
            addView(toggle); addView(close)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(16) }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(box, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (e.x < toggle.width) {
                        enabled = !enabled; absent = 99
                        toggle.text = if (enabled) "■ ON" else "▶ OFF"
                    } else stopSelf()
                }
            }
            true
        }
        wm.addView(box, lp)
        overlay = box
    }

    override fun onDestroy() {
        running = false
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        vd?.release(); reader?.close()
        projection?.stop()
        if (::thread.isInitialized) thread.quitSafely()
        super.onDestroy()
    }
}
